package main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

/**
 * Main class that launches the scheduling desktop application.
 * <p>
 * This class is responsible for initializing and displaying the primary stage and scene,
 * serving as the entry point for the JavaFX application.
 *<p>
 */
public class Main extends Application {
    /**
     * Starts the primary stage for this application.
     * <p>
     * This method loads the main application scene from an FXML file and sets it on the primary stage.
     *
     * @param stage The primary stage for this application, onto which the application scene is set.
     * @throws IOException If loading the FXML resource fails.
     */
    @Override
    public void start(Stage stage) throws IOException {
        Parent root = FXMLLoader.load(Main.class.getResource("/view/MainScreen.fxml"));
        stage.setTitle("Scheduling Tool");
        stage.setScene(new Scene(root, 800, 600));
        stage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * <p>
     * The Javadoc files are located in inventoryfxmlapp/javadoc
     * <p>
     * @param args the command line arguments
     * <p>
     */
    public static void main(String[] args) {
        launch(args);
    }

}
